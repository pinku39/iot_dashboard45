<!DOCTYPE html>
<html>
<head>
    <title>Humidity_Table</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/luxon/3.4.3/luxon.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/plotly.js/2.26.0/plotly.min.js"></script>
    <style>
        /* Set the width of the chart container to 100% */
        .chart-container {
            width: 100%;
            padding: 20px;
        }

        /* Style the dropdown button */
        #dateSelector {
            padding: 10px;
            border: none;
            background-color: blue; /* Blue background color */
            color: white;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        /* Style the dropdown options */
        #dateSelector option {
            background-color: white; 
            color: black;
        }
    </style>
</head>
<body>
    <center><h1 style="color: blue;">Humidity</h1></center>

    <!-- Dropdown menu to select date -->
    <select id="dateSelector" onchange="updateGraph()">
        <option value="all">Merge All Dates_pinku</option> <!-- Fixed option value and removed disabled attribute -->
    </select>

    <!-- Data display -->
    <div id="dataDisplay">
        <!-- Your data display content here -->
        <!-- You can add your own content here as needed -->
    </div>

    <div id="chart-container">
        <div id="myChart"></div>
    </div>

    <script>
        // Function to populate the dropdown menu with available dates
        function populateDateSelector(data) {
            var dateSelector = document.getElementById("dateSelector");
            dateSelector.innerHTML = '<option value="" disabled selected>Select a Date</option>';

            if (Array.isArray(data) && data.length > 0) {
                var uniqueDates = Array.from(new Set(data.map(item => new Date(item.timestamp).toLocaleDateString())));

                uniqueDates.forEach(function (date) {
                    dateSelector.innerHTML += '<option value="' + date + '">' + date + '</option>';
                });
            }
        }

        // Function to update the graph based on the selected date
        function updateGraph() {
            var selectedDate = document.getElementById("dateSelector").value;

            if (selectedDate) {
                if (selectedDate === "all") {
                    // Handle the case for merging all dates and creating one graph
                    selectedDate = null; // Set selectedDate to null to indicate merging
                }

                $.get('humidity_db.php', function (data) {
                    if (Array.isArray(data) && data.length > 0) {
                        var dataForSelectedDate;

                        if (selectedDate) {
                            var selectedDateFormatted = new Date(selectedDate).toLocaleDateString();
                            dataForSelectedDate = data.filter(function (item) {
                                return new Date(item.timestamp).toLocaleDateString() === selectedDateFormatted;
                            });
                        } else {
                            // Merge all dates and create one graph
                            dataForSelectedDate = data;
                        }

                        var values = dataForSelectedDate.map(function (item) {
                            return parseFloat(item.value);
                        });
                        var timestamps = dataForSelectedDate.map(function (item) {
                            return item.timestamp;
                        });

                        if (values.length > 0 && timestamps.length > 0) {
                            var trace = {
                                x: timestamps,
                                y: values,
                                mode: 'lines',
                                type: 'scatter',
                                name: 'Value vs. Timestamp',
                                line: { color: 'rgb(75, 192, 192)' }
                            };

                            var layout = {
                                xaxis: {
                                    title: 'Date & Time'
                                },
                                yaxis: {
                                    title: 'Values'
                                }
                            };

                            Plotly.newPlot('myChart', [trace], layout);
                        } else {
                            console.error("No valid data points for chart creation on date:", selectedDateFormatted);
                        }
                    } else {
                        console.error("Received empty or invalid data:", data);
                    }
                }).fail(function (error) {
                    console.error("Error fetching data:", error);
                });
            }
        }

        // Fetch data from the server initially and populate the dropdown
        $.get('humidity_db.php', function (data) {
            if (Array.isArray(data) && data.length > 0) {
                populateDateSelector(data);
                updateGraph(); // Update the graph with the initial selected date
            } else {
                console.error("Received empty or invalid data:", data);
            }
        }).fail(function (error) {
            console.error("Error fetching data:", error);
        });
    </script>
</body>
</html>
