<!DOCTYPE html>
<html>
<head>
    <title>Gas_graph
    </title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/luxon/3.4.3/luxon.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/plotly.js/2.26.0/plotly.min.js"></script>
    <style>
        /* Set the width of the chart container to 100% */
        #chart-container {
            width: 100%;
            height: 100vh; /* Set the height to 100% of the viewport height */
            padding: 20px;
        }

        /* Clear floating elements after the chart */
        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }

        /* Style for the data display */
        #dataDisplay {
            width: 66%; /* Set the width of the data display to two-thirds of the page */
            float: left;
            padding: 20px;
        }
    </style>
</head>
<body>
    <center><h1>Gas concentration</h1></center>

    <div class="clearfix">
        <!-- Chart container -->
        <div id="chart-container">
            <div id="myChart"></div>
        </div>

        <!-- Data display -->
        <div id="dataDisplay">
            <!-- Your data display content here -->
            <!-- You can add your own content here as needed -->
        </div>
    </div>

    <script>
        // Fetch data from the server
        function fetchData() {
            $.get('mq_db.php', function (data) {
                if (Array.isArray(data) && data.length > 0) {
                    // Extract values and timestamps from the data
                    var values = data.map(function(item) {
                        return parseFloat(item.value);
                    });
                    var timestamps = data.map(function(item) {
                        return item.timestamp;
                    });

                    if (values.length > 0 && timestamps.length > 0) {
                        // Create a trace for the chart
                        var trace = {
                            x: timestamps,
                            y: values,
                            mode: 'lines',
                            type: 'scatter',
                            name: 'Value vs. Timestamp',
                            line: { color: 'rgb(75, 192, 192)' }
                        };

                        // Define layout for the chart
                        var layout = {
                            xaxis: {
                                title: 'Timestamp'
                            },
                            yaxis: {
                                title: 'Value'
                            }
                        };

                        // Create the chart
                        Plotly.newPlot('myChart', [trace], layout);
                    } else {
                        console.error("No valid data points for chart creation.");
                    }
                } else {
                    console.error("Received empty or invalid data:", data);
                }
            }).fail(function (error) {
                console.error("Error fetching data:", error);
            });
        }

        // Fetch data on page load
        fetchData();

        // Function to periodically fetch data from the server (e.g., every 10 seconds)
        function fetchDataFromServer() {
            fetchData();
        }

        // Set an interval to periodically fetch data
        setInterval(fetchDataFromServer, 10000);

        // Function to load XML document
        function loadXMLDoc() {
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    // Update the data display content
                    document.getElementById("data-table-body").innerHTML = this.responseText;
                }
            };
            xhttp.open("GET", "mq_db.php", true);
            xhttp.send();
        }

        // Load XML document on page load and at intervals
        setInterval(loadXMLDoc, 1000);
        window.onload = loadXMLDoc;
    </script>
</body>
</html>
