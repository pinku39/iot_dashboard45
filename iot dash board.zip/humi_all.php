<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>humi_table</title>
    <style>
       body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }

        /* Add your CSS styles here */
        /* Styles for header */
        .header {
            text-align: center;
            padding: 20px;
            background-color: #1e90ff; /* Blue color for the header */
            color: white;
        }

        /* Styles for college info */
        .college-info {
            text-align: center;
            margin-bottom: 20px;
        }

        .college-info h1 {
            font-size: 24px;
            color: #333; /* Dark gray for text */
        }

        .college-info img {
            max-width: 150px;
        }
        /* Styles for table container */
        .table-container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin: 0 auto;
            max-width: 1200px;
        }

        /* Styles for data tables */
        .data-table {
            width: 48%;
            margin-bottom: 20px;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #1e90ff; /* Blue color for table headings */
            color: white; /* White text for table headings */
        }
        .button-container {
            text-align: center;
            margin-top: 20px;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #1e90ff; /* Blue color for the button */
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            margin: 10px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Data Monitoring</h1>
    </div>

    <div class="college-info">
        <h1>Centurion University of Technology and Management</h1>
    </div>

    <div style="display: flex; justify-content: center; align-items: center; height: 100vh;">
        <!-- Humidity Table -->
        <div class="data-table">
            <center>
                <h2>Humidity</h2>
            </center>
            <table>
                <thead>
                    <tr>
                        <th>Sl No.</th>
                        <th>Humidity</th>
                        <th>Date Time</th>
                    </tr>
                </thead>
                <tbody id="humidityData">
                    <!-- Data will be dynamically added here using JavaScript -->
                </tbody>
            </table>
        </div>
    </div>

    <!-- JavaScript for populating the humidity table -->
    <script>
        // Function to populate the humidity table
        function populateHumidityTable(data) {
            const tableBody = document.getElementById('humidityData');
            tableBody.innerHTML = '';

            data.forEach((item, index) => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${item.value}</td>
                    <td>${item.timestamp}</td>
                `;
                tableBody.appendChild(row);
            });
        }

        // Function to fetch real-time humidity data from the server (PHP script)
        function fetchHumidityDataFromServer() {
            // Fetch humidity data using Fetch API
            fetch('main_db.php') // Update the URL to the location of your PHP script
                .then(response => response.json())
                .then(data => {
                    populateHumidityTable(data.humidityData);
                })
                .catch(error => console.error('Error fetching humidity data:', error));
        }

        // Fetch real-time humidity data on page load
        fetchHumidityDataFromServer();
    </script>
</body>
</html>
