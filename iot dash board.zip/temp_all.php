<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Temp_table</title>
    <style>
       body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }

        /* Add your CSS styles here */
        /* Styles for header */
        .header {
            text-align: center;
            padding: 20px;
            background-color: #1e90ff; /* Blue color for the header */
            color: white;
        }

        /* Styles for college info */
        .college-info {
            text-align: center;
            margin-bottom: 20px;
        }

        .college-info h1 {
            font-size: 24px;
            color: #333; /* Dark gray for text */
        }

        .college-info img {
            max-width: 150px;
        }

        

        /* Styles for table container */
        .table-container {
            display: flex;
            justify-content: center; /* Center horizontally */
            align-items: center; /* Center vertically */
            height: 100vh;
        }

        /* Styles for data tables */
        .data-table {
            width: 48%;
            margin-bottom: 20px;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #1e90ff; /* Blue color for table headings */
            color: white; /* White text for table headings */
        }
        .button-container {
            text-align: center;
            margin-top: 20px;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #1e90ff; /* Blue color for the button */
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            margin: 10px;
        }
    </style>
</head>
<body>
<div class="header">
        <h1>Data Monitoring</h1>
    </div>

    <div class="college-info">
        <h1>Centurion University of Technology and Management</h1>
    </div>
    <center>
        <div class="table-container">
         <div class="data-table">
            <center>
                <h2>DHT11</h2>
            </center>
            <table>
                <thead>
                    <tr>
                        <th>Sl No.</th>
                        <th>Temperature</th>
                        <th>Date Time</th>
                    </tr>
                </thead>
                <tbody id="temperatureData">
                    <!-- Data will be dynamically added here using JavaScript -->
                </tbody>
            </table>
         </div>  
        </div>
    </center>
        

    <!-- JavaScript for populating the tables -->
    <script>
        // Function to populate a table
        function populateTable(tableId, data) {
            const tableBody = document.getElementById(tableId);
            tableBody.innerHTML = '';

            data.forEach((item, index) => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${item.value}</td>
                    <td>${item.timestamp}</td>
                `;
                tableBody.appendChild(row);
            });
        }

        // Function to fetch real-time data from the server (PHP script)
        function fetchDataFromServer() {
            // Fetch data using Fetch API
            fetch('main_db.php') // Update the URL to the location of your PHP script
                .then(response => response.json())
                .then(data => {
                    populateTable('temperatureData', data.temperatureData);
                    populateTable('humidityData', data.humidityData);
                    populateTable('lightData', data.lightData);
                    populateTable('gasConcentrationData', data.gasConcentrationData);
                })
                .catch(error => console.error('Error fetching data:', error));
        }

        // Fetch real-time data on page load
        fetchDataFromServer();
    </script>
</body>
</html>