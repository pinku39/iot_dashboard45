<?php
// Database connection parameters
$dbHost = "localhost";
$dbUser = "root";
$dbPassword = "";
$dbName = "jini";

// Create a database connection
$conn = new mysqli($dbHost, $dbUser, $dbPassword, $dbName);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the temperature table
$temperatureData = array();
$sql = "SELECT * FROM temperature";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $temperatureData[] = $row;
    }
}

// Fetch data from the humidity table
$humidityData = array();
$sql = "SELECT * FROM humidity";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $humidityData[] = $row;
    }
}

// Fetch data from the ldr table
$ldrData = array();
$sql = "SELECT * FROM ldr";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $ldrData[] = $row;
    }
}

// Fetch data from the mq135 table
$mq135Data = array();
$sql = "SELECT * FROM mq135";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $mq135Data[] = $row;
    }
}

// Close the database connection
$conn->close();

// Prepare data to be sent as JSON
$data = array(
    "temperatureData" => $temperatureData,
    "humidityData" => $humidityData,
    "ldrData" => $ldrData,
    "mq135Data" => $mq135Data
);

// Send data as JSON
header("Content-type: application/json");
echo json_encode($data);
?>
