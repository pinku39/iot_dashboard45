<!DOCTYPE html>
<html>
<head>
    <title>Yes/No Value Chart</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<body>
    <center><h1>Light Status</h1></center>
    <div id="chart-container">
        <div id="yesNoChart"></div>
    </div>

    <script>
        // Fetch data from the server
        function fetchData() {
            $.get('light_db.php', function (data) {
                if (Array.isArray(data) && data.length > 0) {
                    // Count "Yes" and "No" values
                    var yesCount = data.filter(item => item.value === 'yes').length;
                    var noCount = data.filter(item => item.value === 'no').length;

                    // Create data for the bar chart
                    var chartData = [{
                        x: ['Yes', 'No'],
                        y: [yesCount, noCount],
                        type: 'bar',
                        marker: {
                            color: ['green', 'red']
                        }
                    }];

                    // Define layout for the chart
                    var layout = {
                        title: 'Yes/No Value Chart',
                        xaxis: {
                            title: 'Value'
                        },
                        yaxis: {
                            title: 'Count'
                        }
                    };

                    // Create the chart
                    Plotly.newPlot('yesNoChart', chartData, layout);
                } else {
                    console.error("No valid data points for chart creation.");
                }
            }).fail(function (error) {
                console.error("Error fetching data:", error);
            });
        }

        // Fetch data on page load
        fetchData();

        // Function to periodically fetch data from the server (e.g., every 10 seconds)
        function fetchDataFromServer() {
            fetchData();
        }

        // Set an interval to periodically fetch data
        setInterval(fetchDataFromServer, 10000);
    </script>
</body>
</html>
