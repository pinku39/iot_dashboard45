<?php
$host = 'localhost'; // Hostname
$username = 'root';  // MySQL username
$password = '';      // MySQL password (leave blank if no password)
$database = 'jini'; // Name of your database

// Create a database connection
$mysqli = new mysqli($host, $username, $password, $database);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Fetch data from the database table
$sql = "SELECT * FROM mq135"; // Replace 'your_table_name' with the actual table name
$result = $mysqli->query($sql);

$data = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Close the database connection
$mysqli->close();

// Convert data to JSON format
$jsonData = json_encode($data);

// Output JSON data
header('Content-Type: application/json');
echo $jsonData;
?>
