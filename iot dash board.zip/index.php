<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Monitoring</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }

        /* Add your CSS styles here */
        /* Styles for header */
        .header {
            text-align: center;
            padding: 20px;
            background-color: #1e90ff; /* Blue color for the header */
            color: white;
        }

        /* Styles for college info */
        .college-info {
            text-align: center;
            margin-bottom: 20px;
        }

        .college-info h1 {
            font-size: 24px;
            color: #333; /* Dark gray for text */
        }

        .college-info img {
            max-width: 150px;
        }

        /* Styles for team members section */
        .team-members {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            padding: 20px;
        }

        /* Styles for team member card */
        .team-member {
            width: 23%;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            padding: 10px;
            text-align: center;
        }

        .team-member img {
            max-width: 100px;
            border-radius: 50%;
            margin-bottom: 10px;
        }

        .team-member h3 {
            font-size: 16px;
            color: #333; /* Dark gray for text */
        }

        /* Styles for social links */
        .social-links {
            margin-top: 10px;
        }

        .social-links a {
            text-decoration: none;
            color: #0077b5; /* Blue color for links */
            margin: 0 5px;
        }

        /* Styles for table container */
        .table-container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin: 0 auto;
            max-width: 1200px;
        }

        /* Styles for data tables */
        .data-table {
            width: 48%;
            margin-bottom: 20px;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #1e90ff; /* Blue color for table headings */
            color: white; /* White text for table headings */
        }
        .button-container {
            text-align: center;
            margin-top: 20px;
        }

        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #1e90ff; /* Blue color for the button */
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            margin: 10px;
        }

        .button:hover {
            background-color: #0077b5; /* Darker blue color on hover */
        }
        
    </style>
</head>
<body>
    <div class="header">
        <h1>Data Monitoring</h1>
    </div>

    <div class="college-info">
        <h1>Centurion University of Technology and Management</h1>
    </div>
    <div class="table-container">
        <!-- Temperature Table -->
        <div class="data-table">
            <center>
                <h2>DHT11</h2>
            </center>
            <table>
                <thead>
                    <tr>
                        <th>Sl No.</th>
                        <th>Temperature</th>
                        <th>Date Time</th>
                    </tr>
                </thead>
                <tbody id="temperatureData">
                    <!-- Data will be dynamically added here using JavaScript -->
                </tbody>
            </table>
            <div class="button-container">
                <a class="button" href="t_grap2.php" target="_blank">Analytics</a>
                <a class="button" href="temp_all.php" target="_blank">See All</a>
            </div>
   
        </div>

        <!-- Humidity Table -->
        <div class="data-table">
            <center>
                <h2>DHT11</h2>
            </center>
            <table>
                <thead>
                    <tr>
                        <th>Sl No.</th>
                        <th>Humidity</th>
                        <th>Date Time</th>
                    </tr>
                </thead>
                <tbody id="humidityData">
                    <!-- Data will be dynamically added here using JavaScript -->
                </tbody>
            </table>
            <div class="button-container">
                <a class="button" href="humidity_graph.php" target="_blank">Analytics</a>
                <a class="button" href="humi_all.php" target="_blank">See All</a>
            </div>
        </div>

        <!-- Light Table -->
        <div class="data-table">
            <center>
                <h2>LDR</h2>
            </center>
            <table>
                <thead>
                    <tr>
                        <th>Sl No.</th>
                        <th>Light</th>
                        <th>Date Time</th>
                    </tr>
                </thead>
                <tbody id="lightData">
                    <!-- Data will be dynamically added here using JavaScript -->
                </tbody>
            </table>
            <div class="button-container">
                <a class="button" href="light_graph.php" target="_blank">Analytics</a>
                <a class="button" href="light_all.php" target="_blank">See All</a>
            </div>
        </div>

        <!-- Gas Concentration Table -->
        <div class="data-table">
            <center>
                <h2>MQ135</h2>
            </center>
            <table>
                <thead>
                    <tr>
                        <th>Sl No.</th>
                        <th>Gas Concentration</th>
                        <th>Date Time</th>
                    </tr>
                </thead>
                <tbody id="gasConcentrationData">
                    <!-- Data will be dynamically added here using JavaScript -->
                </tbody>
            </table>
            <div class="button-container">
                <a class="button" href="mq_graph.php" target="_blank">Analytics</a>
                <a class="button" href="mq_all.php" target="_blank">See All</a>
            </div>
        </div>
    </div>
</div>
    </div>
    
    <div class="team-members">
        <!-- Team Member 1 -->
        <div class="team-member">
            <img src="PINKU.jpg" alt="Member 1">
            <h3>Smruti ranjan maharana</h3>
            <div class="social-links">
                <a href="https://www.linkedin.com/in/smruti-ranjan-maharana-258791239/" target="_blank">LinkedIn</a>
                <a href="https://github.com/pinku39" target="_blank">Github</a>
                <a href="https://www.facebook.com/smrutiranjan.maharana.5473" target="_blank">Facebook</a>
                <p>pinkusmruti8@gmail.com</p>
            </div>
        </div>

        <!-- Team Member 2 -->
        <div class="team-member">
            <img src="PINKU.jpg" alt="Member 2">
            <h3>Team Member 2</h3>
            <div class="social-links">
                <a href="#" target="_blank">LinkedIn</a>
                <a href="#" target="_blank">Twitter</a>
                <a href="#" target="_blank">Facebook</a>
            </div>
        </div>

        <!-- Team Member 3 -->
        <div class="team-member">
            <img src="PINKU.jpg" alt="Member 3">
            <h3>Team Member 3</h3>
            <div class="social-links">
                <a href="#" target="_blank">LinkedIn</a>
                <a href="#" target="_blank">Twitter</a>
                <a href="#" target="_blank">Facebook</a>
            </div>
        </div>

        <!-- Team Member 4 -->
        <div class="team-member">
            <img src="PINKU.jpg" alt="Member 4">
            <h3>Team Member 4</h3>
            <div class="social-links">
                <a href="#" target="_blank">LinkedIn</a>
                <a href="#" target="_blank">Twitter</a>
                <a href="#" target="_blank">Facebook</a>
            </div>
        </div>
    </div>
</div>
<center><h3 style="color: blue;">Guided by: Swarna Prabha jena</h1></center>
    <!-- JavaScript for populating the tables -->
    <script>
        // Function to populate a table with the last two recent data entries
        function populateTable(tableId, data) {
            const tableBody = document.getElementById(tableId);
            tableBody.innerHTML = '';

            // Get the last two entries from the data array in reverse order
            const lastTwoEntries = data.slice(-2).reverse();

            lastTwoEntries.forEach((item, index) => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${data.length - index}</td>
                    <td>${item.value}</td>
                    <td>${item.timestamp}</td>
                `;
                tableBody.appendChild(row);
            });
        }

        // Function to fetch real-time data from the server (PHP script)
        function fetchDataFromServer() {
            // Fetch data using Fetch API
            fetch('main_db.php') // Replace with the actual URL
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data) {
                        // Populate tables based on data
                        if (data.temperatureData) {
                            populateTable('temperatureData', data.temperatureData);
                        }
                        if (data.humidityData) {
                            populateTable('humidityData', data.humidityData);
                        }
                        if (data.ldrData) {
                            populateTable('lightData', data.ldrData);
                        }
                        if (data.mq135Data) {
                            populateTable('gasConcentrationData', data.mq135Data);
                        }
                    } else {
                        console.error('No data received from the server.');
                    }
                })
                .catch(error => console.error('Error fetching data:', error));
        }

        // Fetch real-time data on page load
        fetchDataFromServer();
        // Set an interval to periodically fetch data (e.g., every 10 seconds)
        setInterval(fetchDataFromServer, 10000);
        
    </script>
</body>
</html>
